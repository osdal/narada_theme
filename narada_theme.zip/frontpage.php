<?php
/*
Template Name: Главная страница шаблон
*/
?>
<?php get_header('frontpage'); ?>

<main class="page">
	<div class="main__slogan">
		<?php the_content( ) ?>
	</div>
</main>
		


<?php get_footer(); ?>