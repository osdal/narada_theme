jQuery(document).ready(function ($) {
	alert('Work');
});