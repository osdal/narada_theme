
<footer class="footer">
			<div class="footer__container">
				<div class="social_icons">
					<img src=<?php echo get_template_directory_uri() . '/assets/img/icons/Instagram_WC.svg'?>>
					<img src=<?php echo get_template_directory_uri() . '/assets/img/icons/Facebook1.svg'?>>
					<img src=<?php echo get_template_directory_uri() . '/assets/img/icons/Telegram1.svg'?>>
				</div>
			</div>
</footer>
	

<?php wp_footer(); ?>

</body>

</html>